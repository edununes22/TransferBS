assinatura = (input(
    "Por favor, informe o número que corresponde ao nível da assinatura do cliente, sendo: \n1 para Basic\n2 para Silver\n3 para Gold \n4 para Platinum \n->"))
faturamento_anual = float(input("Por favor, digite o valor do faturamento anual do cliente: "))
valor_bonus = 0.0

#O valor de comparação para as assinaturas foi convertido em string, 
# assim a mensagem de erro ainda será exibido caso o input contenha um 0 na frente.
if assinatura == str(1):
    valor_bonus = faturamento_anual * 0.3
elif assinatura == str(2):
    valor_bonus = faturamento_anual * 0.2
elif assinatura == str(3):
    valor_bonus = faturamento_anual * 0.1
elif assinatura == str(4):
    valor_bonus = faturamento_anual * 0.05
    print("O valor a ser pago pelo cliente é de R${:.2f}".format(valor_bonus))
else:
    print("O número digitado não corresponde a nenhuma das categorias, tente novamente!")