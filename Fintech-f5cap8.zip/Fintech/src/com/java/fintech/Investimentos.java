package com.java.fintech;

public class Investimentos {
	
	private double saldoInvest;
	private String tipo;
	private String dataInvest;
	private String vencimento;
	
	public Investimentos() {}
	
	public Investimentos(double saldoInvest, String tipo, String dataInvest, String vencimento) {
		this.saldoInvest = saldoInvest;
		this.tipo = tipo;
		this.dataInvest = dataInvest;
		this.vencimento = vencimento;
	}

	public double getSaldoInvest() {
		System.out.println(saldoInvest);
		return saldoInvest;
	}

	public void setSaldoInvest(double saldoInvest) {
		this.saldoInvest = saldoInvest;
	}

	public String getTipo() {
		System.out.println(tipo);
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDataInvest() {
		System.out.println(dataInvest);
		return dataInvest;
	}

	public void setDataInvest(String dataInvest) {
		this.dataInvest = dataInvest;
	}

	public String getVencimento() {
		System.out.println(vencimento);
		return vencimento;
	}

	public void setVencimento(String vencimento) {
		this.vencimento = vencimento;
	}

	public void adicionarInvestimento(double valor) {
		saldoInvest += valor;
	}
	
	public void removerInvestimentos(double valor) {
		saldoInvest -= valor;
	}
	

}
