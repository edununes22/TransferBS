package com.java.fintech;

public class Carteira {
	
	private double saldo;
	
	public Carteira() {};

	public Carteira(double saldo) {
		this.saldo = saldo;
	}
	
	public void registraGanho(double valor) {
		this.saldo += valor;
	}
	
	public void registraGasto(double valor) {
		this.saldo -= valor;	
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public void extrato() {
//		implementar logica para gerar registro de transacoes 
	}
	
	public void gerarDashboard() {
//		implementar logica para gerar graficos de classificacao de ganhos e gastos 
	}

}
