package com.java.fintech;

public class Curso extends Classificacao {
	
	public String conteudo;
	
	public void apresentaCurso(int tipoCurso) {
		
		switch(tipoCurso) {
			case 1:
				System.out.println("Curso 'Primeiros passos em Educação Financeira'!");
//				fazer logica para direcionar ao curso AQUI
				break;
			case 2:
				System.out.println("Curso 'Próximos passos em Educação Financeira'!");
//				fazer logica para direcionar ao curso AQUI
				break;
			case 3:
				System.out.println("Curso 'Um mergulho mais profundo em Educação Financeira'!");
//				fazer logica para direcionar ao curso AQUI
				break;
			default:
				System.out.println("Curso não encontrado!");
		}
		
	}

}
