package com.java.fintech;

public class Quiz {

	private String pergunta;
	private int resultado;
	protected String tipoPerfil;
	private boolean[] respostas = new boolean[10];
	
	public String getPergunta() {
		return pergunta;
	}

	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}

	public int getResultado() {
		return resultado;
	}

	public void setResultado(int resultado) {
		this.resultado = resultado;
	}

	public boolean[] getRespostas() {
		return respostas;
	}

	public void setRespostas(boolean[] respostas) {
		this.respostas = respostas;
	}
	
//	IMPLEMENTAR LOGICA PARA FAZER O QUIZ - ACESSAR AS PERGUNTAS E ARMAZENAR AS RESPOSTAS

	public int classificaPerfil() {
		
		for(int i = 0; i < respostas.length; i++) {
			
			if (respostas[i] == true) {
				resultado += 1;
			} 
			
		}
		
		if (resultado >= 3) {
			System.out.println("Você está no perfil INICIANTE!");
			tipoPerfil = "Iniciante"; 
		} else if (resultado >= 7) {
			System.out.println("Você está no perfil INTERMEDIÁRIO!");
			tipoPerfil = "Intermediario";
		} else {
			System.out.println("Você está no perfile AVANÇADO!");
			tipoPerfil = "Avancado";
		}
		
		return resultado;
	}
	
	
//	implementar logica para armazenar as respostas das questoes de multipla escolha (quiz)
//  sinalizando true para respostas certas e false para erradas
	
	
}
