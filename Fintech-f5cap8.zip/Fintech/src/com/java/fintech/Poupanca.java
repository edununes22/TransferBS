package com.java.fintech;

public class Poupanca extends Carteira {
	
	private double saldoPoupanca;
	
	public Poupanca() {}

	public Poupanca(double saldoPoupanca) {
		this.saldoPoupanca = saldoPoupanca;
	};
	
	@Override
	public void registraGanho(double valor) {
		this.saldoPoupanca += valor;
	}
	
	@Override
	public void registraGasto(double valor) {
		this.saldoPoupanca -= valor;	
	}

	public double getSaldoPoupanca() {
		return saldoPoupanca;
	}

	public void setSaldoPoupanca(double saldoPoupanca) {
		this.saldoPoupanca = saldoPoupanca;
	}
	
}
