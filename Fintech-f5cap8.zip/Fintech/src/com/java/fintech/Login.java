package com.java.fintech;

import java.util.Scanner;

public class Login extends Usuario {
	
	public void autenticarLogin() {
		
		Scanner scan = new Scanner (System.in);
		System.out.println("Digite o username: ");
		String userName = scan.next();
		System.out.println("Digite a senha: ");
		String userSenha = scan.next();
		
		
		if (userName.equals(getIdUsuario()) && userSenha.equals(getSenha())) {
			System.out.println("Login realizado com sucesso!");	
		} else {
			System.out.println("Username ou senha incorretos!");
			autenticarLogin();
		}
		
	}

}
