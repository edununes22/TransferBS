package com.java.fintech;

public class Teste {

	public static void main(String[] args) {
		
		Usuario user1 = new Usuario("Maria", "1234", "11/11/1991", "cadastro@...", "Feminino");
		user1.getIdUsuario();
		user1.setEmail("atualizando@...");
		user1.getEmail();
		
		Investimentos invest1 = new Investimentos(1000.50, "CDB", "11/2021", "11/2025");
		invest1.getSaldoInvest();
		invest1.setTipo("Tesouro direto");
		invest1.getTipo();
		invest1.adicionarInvestimento(1000);
		invest1.getSaldoInvest();

	}

}
