package com.java.fintech;

public class Classificacao extends Quiz {
	
	private int tipoCurso;
	
	public int getTipoCurso() {
		return tipoCurso;
	}
	
	public void setTipoCurso(int tipoCurso) {
		this.tipoCurso = tipoCurso;
	}

	public int direcionaCurso(String tipoPerfil) {
		
		switch (tipoPerfil) {
			case "Iniciante":
				tipoCurso = 1;
				break;
			case "Intermediario":
				tipoCurso = 2;
				break;
			case "Avancado":
				tipoCurso = 3;
				break;
			default:
				System.out.println("Não encontramos sua categoria!");
		
		}
		
		return tipoCurso;
		
	}
	
}
