package com.java.fintech;

public class Usuario {
	
	private String idUsuario;
	private String senha;
	private String dtNasc;
	private String email;
	private String sexo;
	
	public Usuario() {}

	public Usuario(String idUsuario, String senha, String dtNasc, String email, String sexo) {
		this.idUsuario = idUsuario;
		this.senha = senha;
		this.dtNasc = dtNasc;
		this.email = email;
		this.sexo = sexo;
	}

	public String getIdUsuario() {
		System.out.println(idUsuario);
		return idUsuario;
	}

	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}
	
	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getDtNasc() {
		System.out.println(dtNasc);
		return dtNasc;
	}

	public void setDtNasc(String dtNasc) {
		this.dtNasc = dtNasc;
	}

	public String getEmail() {
		System.out.println(email);
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSexo() {
		System.out.println(sexo);
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	};
	
//	fazer login -> classe Login 
// 	fazer cadastro -> com o metodo construtor, ao instanciar a classe 
//  atualizar cadastro -> com os metodos setters 
		

}
